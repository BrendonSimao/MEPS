
<nav id="sidebar" class='mx-lt-5 bg-transparent' >

		<div class="sidebar-list">

				<a href="index.php?page=home" class="nav-item nav-home"><span class='icon-field'><i class="fa fa-home"></i></span> Home</a>
				<a href="index.php?page=payroll_list" class="nav-item nav-payroll_list"><span class='icon-field'><i class="fa fa-columns"></i></span> Payroll List</a>
				<a href="index.php?page=manage_employee" class="nav-item nav-manage_employee"><span class='icon-field'><i class="fa fa-user-tie"></i></span> Employee List</a>
                 <?php if($_SESSION['type'] == 1): ?>
                <a href="index.php?page=maintenance" class="nav-item nav-maintenance"><span class='icon-field'><i class="fa fa-columns"></i></span> Depatment List</a>
				<a href="index.php?page=maintenance" class="nav-item nav-maintenance"><span class='icon-field'><i class="fa fa-user-tie"></i></span> Position List</a>

				<a href="index.php?page=manage_payroll" class="nav-item manage_payroll"><span class='icon-field'><i class="fa fa-list"></i></span> Allowance List</a>
				<a href="index.php?page=manage_payroll" class="nav-item manage_payroll"><span class='icon-field'><i class="fa fa-money-bill-wave"></i></span> Deduction List</a>
                <a href="index.php?page=tax_table" class="nav-item nav-tax_table"><span class='icon-field'><i class="fa fa-money-bill-wave"></i></span> Tax</a>


				<a href="index.php?page=admin" class="nav-item nav-users"><span class='icon-field'><i class="fa fa-users"></i></span> Users</a>
				
			<?php endif; ?>
		</div>

</nav>
<script>
	$('.nav-<?php echo isset($_GET['page']) ? $_GET['page'] : '' ?>').addClass('active')
</script>
