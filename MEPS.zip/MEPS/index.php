<?php
header("../admin/header.php");
?>